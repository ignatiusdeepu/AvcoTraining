package org.avco.collections;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//create a map which holds string,string.
		Map<String, String> stringMap = new HashMap<String, String>();
		stringMap.put("USER_NAME", "AVCO");
		stringMap.put("PASSWORD", "123");
		stringMap.put("ADDRESS", "129387892");
		stringMap.put("CITY", "WORCESTOR");

		//if we want to retrieve a particular value, lets say username:
		System.out.println(" USERNAME :"+stringMap.get("USER_NAME"));
		
		for(Map.Entry<String, String> entry : stringMap.entrySet()){
			System.out.println(" KEY : "+entry.getKey()+" Value :"+entry.getValue());
		}
	}

}
