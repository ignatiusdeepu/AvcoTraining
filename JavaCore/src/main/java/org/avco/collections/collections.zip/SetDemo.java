package org.avco.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class SetDemo {
	
	// int a[] = new int[10];

	public static void main(String a[]){
		//to create set of Integers and display the values:
		Set<Integer> integerSet = new HashSet<Integer>(2);
		integerSet.add(new Integer(10));
		integerSet.add(new Integer(20));
		integerSet.add(new Integer(10));
		integerSet.add(new Integer(30));
		
		for(Integer i :integerSet ){
			System.out.println("Element Value :"+i.intValue());
		}
		
		Iterator<Integer> iterator = integerSet.iterator();
		while(iterator.hasNext()){
			System.out.println("Element Value :"+iterator.next().intValue());
		}
		
		/*for(int i=0;i<integerSet.size();i++){
			integerSet.ge
		}*/
	}
}
