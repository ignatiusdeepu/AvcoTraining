package org.avco.generics;

public class Triangle {

	public void draw(){
		System.out.println("Drawing Triangle....");
	}
}
