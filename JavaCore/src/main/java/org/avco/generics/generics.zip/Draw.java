package org.avco.generics;

public class Draw {

	private Object shape;
	
	public Draw(Object shape){
		this.shape = shape;
	}

	public Object getShape() {
		return shape;
	}

	public void setShape(Object shape) {
		this.shape = shape;
	}
	
	
}
