package org.avco.generics;

public class DrawGeneric<X> {
	
	private X shape;
	
	public DrawGeneric(X shape){
		this.shape = shape;
	}
	
	public X getShape() {
		return shape;
	}

	public void setShape(X shape) {
		this.shape = shape;
	}

}
