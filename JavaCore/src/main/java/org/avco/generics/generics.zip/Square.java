package org.avco.generics;

public class Square {

	public void draw(){
		System.out.println("Drawing Square....");
	}
}
