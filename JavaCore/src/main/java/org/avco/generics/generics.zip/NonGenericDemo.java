package org.avco.generics;

public class NonGenericDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Draw draw = new Draw(new Circle());
		((Triangle)draw.getShape()).draw();
	}

}
