package org.avco.generics;

public class Circle {

	public void draw(){
		System.out.println("Drawing Circle....");
	}
}
